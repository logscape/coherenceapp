import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection

makeSleep = makeSleep == null ? true : makeSleep
sleepMs = sleepMs == null ? 0 : sleepMs
jmxUrl = jmxUrl == null ? "service:jmx:rmi://localhost:3000/jndi/rmi://localhost:9000/server" : jmxUrl
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

//******

//HIJACK
//jmxUrl = "service:jmx:rmi://192.168.70.226:16331/jndi/rmi://192.168.70.226:16332/server"
  
//*********

def scriptName = "MBeanServers.groovy"
//def pathToScript = bundleId == null ? "lib/"+scriptName : "deployed-bundles/"+bundleId+"/lib/"+scriptName
def pathToScript = cwd == null ? "lib/"+scriptName : cwd + "/deployed-bundles/"+bundleId+"/lib/"+scriptName

def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def mBeanServersClass = loader.parseClass(new File(pathToScript))

//**********

def mBeanServers = mBeanServersClass.newInstance(stdErr,sleepMs)

try {

    
    mBeanServers.addBeans(jmxUrl.split(","))

    if (mBeanServers.size() < 1) {
        stdErr << new Date().toString() + "\t" + "ERROR" + "\t" + "Could not create connect to any of the jmx urls: " + jmxUrls + "\n"
        throw new Exception("Could not connect to any MBeanConnectors")
    }
    
    def serviceMap = [:]
    
    def serviceObjNames = mBeanServers.queryNames("Coherence:type=Service,name=*,nodeId=*")

	def services = []
	def caches = [] 

   serviceObjNames.each { x ->
	try{
		def name = x.getKeyProperty('name')
		cacheService = new CacheService(x,mBeanServers)
		cacheService.collect()
	
		if (!services.contains(cacheService.name)){
			def cacheObjNames = mBeanServers.queryNames("Coherence:type=Cache,service=" + cacheService.name + ",name=*,nodeId=*,tier=back")

			
			if ( cacheObjNames.size() >  0 )  // storage node 
			{
				cacheObjNames.each { z ->      
				       cacheService.collectCacheInfo(z)
		  	       
				       if (makeSleep) {
					       Thread.sleep(10+sleepMs)
				       }	  
				}
			}else{
				       cacheService.collectProxyInfo(cacheService.name, serviceObjNames)

				//nonStorageNodes  = mBeanServers.queryNames("Coherence:type=Service,name="+cacheService.name+",nodeId=*")
				//println nonStorageNodes.size() 

			}

			services.add(cacheService.name) 
			stdOut <<  cacheService.printMe(["Name","NodeCount","StatusHA","StorageEnabledCount","SeniorMemberId","ObjectCount","CacheCount"],",") << "\n"
		}
	}catch(Exception e){

		stdErr << e.getMessage() + "\n"
	}

        if (makeSleep) {
            Thread.sleep(10+sleepMs)
        }

   }
   return
    
} finally {
    mBeanServers.closeConnections()
}

//*****

private class CacheService {
    def objName
    def mBeanServers
    
    def name = ""
    def statusHA = ""
    def nodeCount = 0
    def storageCount = 0
    def cacheCount = 0
    def objectCount = 0
    def seniorId = 0
    def attributeMap = [:] 
    def sep = ","

    def caches = [] 
    def nodeIds = []
    def services = []	

    public CacheService(objName,mBeanServers) {
        this.objName = objName
        this.mBeanServers = mBeanServers
   
	// attribute map default values

	attributeMap["ObjectCount"] = 0
	attributeMap["StorageCount"] = 0
	attributeMap["CacheCount"] = 0

   }

  def overrideAttribute(key,value)
  {
	if ( attributeMap.containsKey(key) )
	{
		attributeMap[key] = value
	}
  }

  def collect() {
	
	String[]  attributeNames = ['name',"StatusHA","StorageEnabledCount","SeniorMemberId"]
	def attributes = mBeanServers.getAttributes(objName,attributeNames)
        name = objName.getKeyProperty('name')
	
	attributeMap["Name"] = name
	attributeMap["NodeCount"] = nodeIds.size()

	for ( attrib in attributes)
	{
		attributeMap [ attrib.getName() ] = attrib.getValue()  
	}
	
	statusHA = attributeMap [ "StatusHA"]
        storageCount = attributeMap [ "StorageEnabledCount"]
        seniorId = attributeMap [  "SeniorMemberId"]

    }
    
    def collectProxyInfo(cacheObjectName, serviceObjNames ) {

	attributeMap["NodeCount"] = 0
	
   	serviceObjNames.each { x ->
	try{
		def name = x.getKeyProperty('name')
		if (name == cacheObjectName) {
			attributeMap["NodeCount"] = attributeMap["NodeCount"] +1 
		}

		} catch (Throwable t) {
		}

	}
    }

    def collectCacheInfo(cacheObjectName) {
        def sizeAttrib = mBeanServers.getAttributes(cacheObjectName, "Size")
	def cacheName = cacheObjectName.getKeyProperty("name")
	def nodeId = cacheObjectName.getKeyProperty("nodeId")

        objectCount += sizeAttrib[0].getValue()

	if (!caches.contains(cacheName))
	{
		caches.add(cacheName)
	}

	if (!services.contains(nodeId))	{
		services.add(nodeId) 
	}


	attributeMap["NodeCount"] = services.size() 
	attributeMap["Size"] = sizeAttrib
	attributeMap["ObjectCount"] = objectCount
	attributeMap["CacheCount"] =  caches.size()
    	
    }
    
    def printMe() {
        return new Date().toString() + sep + name + sep + nodeCount + sep + statusHA + sep + storageCount + sep + seniorId + sep + objectCount + sep + cacheCount
    }

    def printMe(cols,sep)
    {
	def line = new Date().toString()
	for ( columnName in cols ){

		if (attributeMap.containsKey(columnName)){

			line = line + sep + attributeMap[ columnName ]			

		}else{

			line = line + sep + "NULL" 			
		}
	}
	return line
    }
}

//********

def propertyMissing(String name) {return null}

def getHeader() {
    return "Date" + sep + "Service" + sep + "NodeCount" + sep + "HA"  + sep + "StorageCount" + sep + "SeniorId" + sep + "objectCount" + sep + "CacheCount"
}
