import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection

makeSleep = makeSleep == null ? true : makeSleep
sleepMs = sleepMs == null ? 0 : sleepMs
jmxUrl = jmxUrl == null ? "service:jmx:rmi://localhost:3000/jndi/rmi://localhost:9000/server" : jmxUrl
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

//******

//HIJACK
//jmxUrl = "service:jmx:rmi://192.168.70.226:16331/jndi/rmi://192.168.70.226:16332/server"

//*********

def scriptName = "MBeanServers.groovy"
def pathToScript = bundleId == null ? "lib/"+scriptName : "deployed-bundles/"+bundleId+"/lib/"+scriptName

def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def mBeanServersClass = loader.parseClass(new File(pathToScript))

//**********

def mBeanServers = mBeanServersClass.newInstance(stdErr,sleepMs)

try {
    mBeanServers.addBeans(jmxUrl.split(","))
    
    if (mBeanServers.size() < 1) {
        stdErr << new Date().toString() + "\t" + "ERROR" + "\t" + "Could not create connect to any of the jmx urls: " + jmxUrls + "\n"
        throw new Exception("Could not connect to any MBeanConnectors")
    }
    
    def x = new ObjectName("Coherence:type=Cluster")     
    
    def cluster = new MemoryInfos(x,mBeanServers)
    cluster.collect()
    
    if (makeSleep == true) {
        Thread.sleep(10+sleepMs)
    }
           
    def result = new StringBuilder();       
    result.append(cluster.printMe()).append("\n") 

    //stdErr << getHeader() + "\n"
    stdOut << result.toString()
    
    return
    
} finally {
    mBeanServers.closeConnections()
}

//******

def propertyMissing(String name) {return null}

def getHeader() {
    def sep = ","
    return  "Date" + sep + "Name" + sep +  "TotalNodesCount" + sep +  "StorageNodesCount" + sep +  "ProxyNodesCount" + sep +  "ManagementNodesCount" + sep +  "ClusterAvbMB" + sep +  "ClusterMaxMB"
}

//******

private class MemoryInfos {
    def id
    def mBeanServers
    
    def name = ""
    
    def allNodesList = []
    def storageNodesList = []
    def proxyNodesList = []
    def managementNodesList = []
    
    def clusterAvbMB = 0;
    def clusterMaxMB = 0;
    
    public MemoryInfos(x,y) {
        id = x
        mBeanServers = y
    }
    
    def collect() {
        name = mBeanServers.getAttribute(id, "ClusterName")
        
        allNodesList = mBeanServers.getAttribute(id, "MemberIds") as ArrayList
        
        def p = mBeanServers.queryNames("Coherence:type=ConnectionManager,name=*,nodeId=*")
        p.each { pr ->
            def node = pr.getKeyProperty('nodeId') as Integer
            if (! proxyNodesList.contains(node))
                proxyNodesList.add(node)
        }
        
        def c = mBeanServers.queryNames("Coherence:type=Service,name=*,nodeId=*").iterator()
        while (c.hasNext()) {
            def y = c.next()
            def node = y.getKeyProperty('nodeId') as Integer
            if (storageNodesList.contains(node))
                continue
            def isStorageEnabled = mBeanServers.getAttribute(y, "StorageEnabled").toString() == "true"
            if (isStorageEnabled && !proxyNodesList.contains(node)) {
                storageNodesList.add(node)
                def z = new ObjectName("Coherence:type=Node,nodeId="+node)
                clusterAvbMB += mBeanServers.getAttribute(z, "MemoryAvailableMB")
                clusterMaxMB += mBeanServers.getAttribute(z, "MemoryMaxMB")
            }
        }
        
        managementNodesList = allNodesList.clone() as ArrayList
        managementNodesList.removeAll(proxyNodesList)
        managementNodesList.removeAll(storageNodesList)

    }
    
    def printMe() {
        def sep = ","
        return  new Date().toString() + sep + name + sep + allNodesList.size() + sep + storageNodesList.size() + sep + proxyNodesList.size() + sep + managementNodesList.size() + sep + clusterAvbMB + sep + clusterMaxMB;
    }
}
