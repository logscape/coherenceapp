import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection

makeSleep = makeSleep == null ? true : makeSleep
sleepMs = sleepMs == null ? 0 : sleepMs
jmxUrl = jmxUrl == null ? "service:jmx:rmi://localhost:3000/jndi/rmi://localhost:9000/server" : jmxUrl
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

//******

//HIJACK
//jmxUrl = "service:jmx:rmi://192.168.70.226:16331/jndi/rmi://192.168.70.226:16332/server"

//*********

def scriptName = "MBeanServers.groovy"
// old lib path def pathToScript = bundleId == null ? "lib/"+scriptName : "deployed-bundles/"+bundleId+"/lib/"+scriptName
def pathToScript = cwd == null ? "lib/"+scriptName : cwd + "/deployed-bundles/"+bundleId+"/lib/"+scriptName

def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def mBeanServersClass = loader.parseClass(new File(pathToScript))

//**********

def mBeanServers = mBeanServersClass.newInstance(stdErr,sleepMs)

try {

    mBeanServers.addBeans(jmxUrl.split(","))

    if (mBeanServers.size() < 1) {
        stdErr << new Date().toString() + "\t" + "ERROR" + "\t" + "Could not create connect to any of the jmx urls: " + jmxUrls + "\n"
        throw new Exception("Could not connect to any MBeanConnectors")
    }
    
    def keys = []
    def nodeMap = [:]
    
    def proxyNodesList = []
    
    def p = mBeanServers.queryNames("Coherence:type=ConnectionManager,name=*,nodeId=*")
    p.each { pr ->
        def node = pr.getKeyProperty('nodeId')
        if (! proxyNodesList.contains(node))
            proxyNodesList.add(node)
    }
    //println "proxies: " + proxyNodesList
    
    def nodeObjNames = mBeanServers.queryNames('Coherence:type=Node,nodeId=*')
    nodeObjNames.each { x ->
        def nid = x.getKeyProperty('nodeId')
        def key = nid
        
        if (makeSleep == true) {
            Thread.sleep(10+sleepMs)
        }
        
        try {
        
            def i = mBeanServers.queryNames('Coherence:type=Service,name=*,nodeId=' + nid).iterator()
            if (nodeMap[(key)] == null) {
                def alreadyAssigned = false
                while(! alreadyAssigned && i.hasNext()) {
                    def y = i.next()
                    def isStorageEnabled = mBeanServers.getAttribute(y, 'StorageEnabled').toString() == "true"
                    //println "service: " + y.getKeyProperty('name') + "\tnodeId: " + nid + "\tstorageEnabled?" + isStorageEnabled
                    if (isStorageEnabled && !proxyNodesList.contains(nid)) {
                        nodeMap[(key)] = new NodeStats(x,mBeanServers)
                        cs = nodeMap[(key)]
                        cs.collect()
                        keys.add(key)
                        
                        alreadyAssigned = true
                    }
                }
            }
        } catch(Exception e) {
            stdErr << e.getMessage() + "\n"
            if (e.getMessage().trim() == "List of MBeanConnectors expired")
                throw e
        }
    }
    
    Collections.sort(keys)
    
           
    def result = new StringBuilder();
    /*
    def clusterMemAvbMB = 0
    def clusterMemMaxMB = 0
    */
    keys.each {x ->
         result.append(nodeMap[(x)].printMe()).append('\n')
         /*
         clusterMemAvbMB += nodeMap[(x)].memAvbMB
         clusterMemMaxMB += nodeMap[(x)].memMaxMB
         */
    }
    
    //def sep = ','; result.append(new Date().toString() + sep + 'MachineName=' + 'CLUSTER' + sep + 'NodeId=' + 'ALLSTORAGE' + sep + 'MemoryAvailableMB=' + clusterMemAvbMB + sep + 'MemoryMaxMB=' + clusterMemMaxMB).append('\n')
    
    
    //stdErr << getHeader() + "\n"
    stdOut << result.toString()
    
    //PRINT CLUSTER INFO, sum of nodes infos
    /*
    def sep = ","
    stdOut << new Date().toString() + sep + "_CLUSTER" + sep + "_CLUSTER" + sep + clusterMemAvbMB + sep + clusterMemMaxMB + "\n"
    */
    
    return
    
} finally {
    mBeanServers.closeConnections()
}

//*****

class NodeStats {
    def id
    def mBeanServers
    
    def nodeId = 0
    
    def machineName = ''
    
    def memAvbMB = 0
    def memMaxMB = 0
    
    public NodeStats(x,y) {
        id = x
        mBeanServers = y
    }
    
    def collect() {
		String[]  attributeNames = ['Id','MachineName','MemoryAvailableMB','MemoryMaxMB']
		
		def attributes = mBeanServers.getAttributes(id,attributeNames)
		def attribMap = [:]
		for ( attrib in attributes)
		{
			attribMap [ attrib.getName() ] = attrib.getValue()  
		}
			

        nodeId = mBeanServers.getAttribute(id, 'Id')
    
        machineName = mBeanServers.getAttribute(id, 'MachineName')
        
        memAvbMB = mBeanServers.getAttribute(id, 'MemoryAvailableMB')
        memMaxMB = mBeanServers.getAttribute(id, 'MemoryMaxMB')
    }

    def collect1() {
        nodeId = mBeanServers.getAttribute(id, 'Id')
    
        machineName = mBeanServers.getAttribute(id, 'MachineName')
        
        memAvbMB = mBeanServers.getAttribute(id, 'MemoryAvailableMB')
        memMaxMB = mBeanServers.getAttribute(id, 'MemoryMaxMB')
    }
    
    def printMe() {
        def sep = ','
        return new Date().toString() + sep + machineName + sep + nodeId + sep + memAvbMB + sep + memMaxMB
    }
}

//*******

def propertyMissing(String name) {return null}

def getHeader() {
    def sep = ','
    return 'Date' + sep + 'MachineName' + sep + 'NodeId' + sep + 'MemoryAvailableMB' + sep + 'MemoryMaxMB'
}
