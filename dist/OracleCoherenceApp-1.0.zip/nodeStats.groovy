import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection

import javax.management.openmbean.CompositeData;
import javax.management.openmbean.TabularData;



def scriptName = "settings.groovy"
def pathToLib = cwd == null ? "lib/"+scriptName : cwd + "/deployed-bundles/"+bundleId+"/lib/"+scriptName

def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def Settings = loader.parseClass(new File(pathToLib))


def settings =  Settings.newInstance()
def arguments  =  args  as List

settings.init(_bindings)

if (settings.global.containsKey("jmxUrl")){
	jmxUrl=settings.global["jmxUrl"]
}
//*******

makeSleep = makeSleep == null ? true : makeSleep
sleepMs = sleepMs == null ? 10 : sleepMs
jmxUrl = jmxUrl == null ? "service:jmx:rmi://localhost:3000/jndi/rmi://localhost:9000/server" : jmxUrl
makeReset = makeReset == null ? true : makeReset

pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

//******

//HIJACK
//jmxUrl = "service:jmx:rmi://192.168.70.226:16331/jndi/rmi://192.168.70.226:16332/server"
//makeReset = false

//*********

 scriptName = "MBeanServers.groovy"
// pathToScript = bundleId == null ? "lib/"+scriptName : "deployed-bundles/"+bundleId+"/lib/"+scriptName

 pathToScript = cwd == null ? "lib/"+scriptName : cwd + "/deployed-bundles/"+bundleId+"/lib/"+scriptName

 parent = getClass().getClassLoader()
 loader = new GroovyClassLoader(parent)
def mBeanServersClass = loader.parseClass(new File(pathToScript))

//**********

def mBeanServers = mBeanServersClass.newInstance(stdErr,sleepMs)

try {

    mBeanServers.addBeans(jmxUrl.split(","))

    if (mBeanServers.size() < 1) {
        stdErr << new Date().toString() + "\t" + "ERROR" + "\t" + "Could not create connect to any of the jmx urls: " + jmxUrls + "\n"
        throw new Exception("Could not connect to any MBeanConnectors")
    }
    
    def keys = []
    def serviceMap = [:]

    def nodeObjNames = mBeanServers.queryNames("Coherence:type=Node,nodeId=*")

    nodeObjNames.each { x ->
	try{
		def nodeId = x.getKeyProperty('nodeId')
		nodeInfo = new NodeStats(x,mBeanServers)
		nodeInfo.collect()

	        
		stdOut << nodeInfo.printMe()  << "\n" 
        	
		if (makeReset == true) {
	            mBeanServers.invoke(x, "resetStatistics")
        	}
        
	}catch(Exception e )
	{
		stdErr << e.getMessage() + "\n"

	}
        if (makeSleep == true) {
            Thread.sleep(10+sleepMs)
        } 


    }
   return
    
    
} finally {
    mBeanServers.closeConnections()
}

//******

private class NodeStats {
    def id
    def mBeanServers
    
    def nodeId = ""
    
    def memberName = ""
    def machineName = ""
    def roleName = ""
    
    def processId = ""
    
    def weakestChannel = ""
    def statistics = ""
    
    def memoryMax = ""
    def memoryAvb = ""
    
    def sep = ";"

    public NodeStats(x,y) {
        id = x
        mBeanServers = y
    }

    def collect() {
        nodeId = id.getKeyProperty("nodeId")
        
		String[]  attributeNames = ["MemberName","MachineName","RoleName","ProcessName","WeakestChannel","Statistics","MemoryMaxMB","MemoryAvailableMB"]
		
		def attributes = mBeanServers.getAttributes(id,attributeNames)
		def attribMap = [:]
		for ( attrib in attributes)
		{
			attribMap [ attrib.getName() ] = attrib.getValue()  
		}
			
		
        memberName =attribMap [ "MemberName"]
        machineName = attribMap [ "MachineName"]
        roleName = attribMap [ "RoleName"]
        
        processId = attribMap [ "ProcessName"]
        
        weakestChannel = attribMap [ "WeakestChannel"]
        statistics = attribMap [ "Statistics"]
        
        memoryMax = attribMap [ "MemoryMaxMB"]
        memoryAvb = attribMap [ "MemoryAvailableMB"]
        
    }   


    
    def printMe() {
         return  new Date().toString() + sep + processId + sep + nodeId + sep + memberName + sep + machineName + sep + roleName + sep + memoryMax + sep + memoryAvb + sep + weakestChannel + sep + statistics.trim().replace("\n", ", ").replace("\t", " ")
    }
}

//*********

def propertyMissing(String name) {return null}

def getHeader() {
     def sep = ";"
     return  "Date" + sep + "processId" + sep + "NodeId" + sep + "MemberName" + sep + "MachineName" + sep + "RoleName" + sep + "MemoryMaxMB" + sep + "MemoryAvailableMB" + sep + "WeakestChannel" + sep + "Statistics"
}
