import org.codehaus.groovy.runtime.StackTraceUtils
import java.text.SimpleDateFormat
import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory as JmxConnectorFactory
import javax.management.remote.JMXServiceURL as JmxServiceUrl
import javax.management.remote.JMXConnector
import javax.management.openmbean.CompositeDataSupport
import javax.management.openmbean.TabularData
import java.lang.NumberFormatException
import groovy.json.JsonBuilder
//http://groovy.codehaus.org/Groovy+and+JMX
/*def bundleId = null
for(def arg:args){
	if (arg.contains("bundleId")){
		bundleId=arg.split("=")[1] 
	}
}*/
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)

def propertyMissing(String name) {}


def scriptName = "settings.groovy"
def pathToLib = cwd == null ? "lib/"+scriptName : cwd + "/deployed-bundles/"+bundleId+"/lib/"+scriptName
def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def Settings = loader.parseClass(new File(pathToLib))

def JBossServiceUrl(ipAddress,port){
	ipAddress="LCYLS00008.sbetenv.ads"
	port="9999"
	return "service:jmx:remoting-jmx://"+ipAddress+":" + "9999"
}


class StrUtils{
	def static  flatten(map){
		def values=[]
		for(def k:map.keySet()){
			if(map[k] instanceof LinkedHashMap){
				values.add(flatten(map[k])) 
			}else{
				values.add(""+k+"=\""+map[k]+"\"")
			}
		}	
		return values.join(", ") 
	}
}

def linuxScan(portRange,serviceUrl,jmxAuth){


	def cmd = [
	'bash',
	'-c',
	''' netstat -lap | grep java | grep 'LISTEN ' | awk '{print $4,$7}' | sed -e 's/\\[\\:\\:\\]\\://' | sort '''.stripMargin() ]


	def connections = [:] 
	
	counter = 0 
	cmd.execute().text.split("\n").each{ line -> 
		(port,pid) = line.split()
		if (port.contains(":") ) { port = port.split(":")[1] }
		try{ 
			port = port.toInteger()
			pid =  pid.split("/")[0].toInteger()
			cred=getAuth ( jmxAuth, counter ) 
			if  ( port > portRange[0]  && port < portRange[1] ) 
			{
				//c = connector( jmxUrl("127.0.0.1",port ))
				c = connect( serviceUrl("127.0.0.1",port ), cred)
				connections[pid] = [
					"port": port
					,"connection":c.MBeanServerConnection 
					,"connector":c
				]



			//	pout <<   "Connected to ... " +  jmxUrl("127.0.0.1",port)  << "\n"
			}

		}catch(ClassCastException e){	
			perr <<  "Skipping ..." +  port  + "," + pid  << "\n"

		}catch(NumberFormatException e){

			// swallow this exception
		}catch(Exception e){

			errorLog ( e )  
			e.printStackTrace(perr)
		}
	

	}

	return connections
}

class Logger{
	private static verbose=false;
	private static Logger instance = null;
	private static pout;
	private static perr;
	private Logger(){}

	def setVerboseTrue(){
		verbose=true;
	}
	
	def getInstance(){
		if(instance==null){
			instance = new Logger();
		}
		return instance;
	}
	def setOutStream(def out){
		pout=out		
	}
	def setErrStream(def err){
		perr=err
	} 
	def log( line ){
		def dt = new Date()
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss zzz"); 
		//def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		def timestamp=dateFormatter.format(dt)
		pout <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def error( line ) { 
		def dt = new Date()
		def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		perr <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def verbose(line){
		if(verbose){
			error(line);
		}
	}
}

def getAuth(auth,index) {
	if (auth == null) { return null } 
	
	elems = auth.split(",")
	if (index > elems.size()  - 1 ) { return null } 
	
	cred = elems[index] 
	if (cred.contains(":")) {
		credArgs =cred.split(":")
		
		return [ (JMXConnector.CREDENTIALS):credArgs ]  	
	}

	return null
}


class Port{
	def port
	def Port(p){
		port =  p
	}

	def isValid(portIntValue){
		if (isRange()){
			def (portBegin,portEnd) = rangeValues() 
			return (  (portIntValue > portBegin) && (portIntValue < portEnd) ) 
		}else if (isInteger()){
			return (intValue() == portIntValue) 
		}
		return false
	}

	def isInteger() {return (port.contains("-") == true) ? false : port.isInteger()  }

	def isRange() {
		if (port.contains("-")) {
			def (v1,v2)=port.split("-");
			return  ( v1.isInteger() &&  v2.isInteger() )
		}
		return false
	}
	def intValue() {
		return port.toInteger()
	} 

	def rangeValues() {
		def (v1,v2) = port.split("-") as List
		def portBegin = v1.toInteger()
		def portEnd = v2.toInteger()
		if (portEnd < portBegin ) {
			throw new Exception("Invalid port-range: " + port ) 
		}
		return[portBegin,portEnd]
	}

	def contains(p) {
		def (portBegin,portEnd) =  rangeValues() 
		if ((p > portBegin) && (p < portEnd )){
			return true
		}

		return false 
	}

	public String toString(){
		return ""+port
	}
}
class JmxUrlBuilder { 
	def scanner
	def ns  
	def JmxUrlBuilder(scanner){
		this.scanner = scanner 
	}

	def generateUrls( urlConfig) {
		def urls = [] 
		def hosts = urlConfig.hosts.split(",")  as List
		def rmiName =(urlConfig.rmi==null)? "jmxrmi" : urlConfig.rmi.name
		def jndiPort=""
		def jndiHost=""
		def jndiUrl=null
		if (urlConfig.jndi !=null){
			jndiPort= (urlConfig.jndi.port==null)? "" : ":"+urlConfig.jndi.port
			jndiHost= (urlConfig.jndi.host==null)? "" : urlConfig.jndi.host
		}
		jndiUrl = (urlConfig.jndi == null) ? "/jndi" : jndiHost + jndiPort+"/jndi"  
		for (host in hosts) {
			def port = (urlConfig.port != null) ? ":" + urlConfig.port   : "" 
			def address = host + port 
			def rmiPart = "rmi://"+address + "/"+rmiName
			def jmxUrl =  "service:jmx:rmi://" + jndiUrl + "/"  +   rmiPart  
			urls.add(jmxUrl) 
		}
		return urls
	}

	def generate() {return generate(this.ns)}

	def generate(ns){
		def ports = ns.ports.split(",") as List  
		def hosts  =  (ns.hosts != null) ?  ns.hosts :  "127.0.0.1"	
		def jmxUrls =  []
		def jmxPorts = [] 
		for (def port:ports){
			def p = new Port(port) 
			
			if (ns.hosts != null) { jmxPorts.add(p.intValue()) ; continue } 
			if (scanner.contains(p)){				
				jmxPorts.addAll( scanner.get(p)) 
			} 
		}
		for (port in jmxPorts){
			def urls =   generateUrls([
						"hosts":hosts
						,"port":port 
						,"jndi":ns.jndi
						,"rmi":ns.rmi

			])
			jmxUrls.addAll(urls)  
		}	
		return jmxUrls  
	}


}
class PortScanner {
	def info = [:]
	def ports = []
	def scannedPorts = [] 
	def add(p){
		ports.add(p) 
	} 

	def isValidPort(port) {

		for(def p:ports){
			if (p.isValid(port)) { return true } 
			 
		}
		return false
	}
	def contains(p){
		
		if (p.isInteger()){
			return scannedPorts.contains(p.intValue())
		}
		if(p.isRange()){
			def (portBegin,portEnd)=p.rangeValues()
			for(def port:scannedPorts){
				if ((port.intValue() >= portBegin) && (port.intValue()  <= portEnd) ){
					return true
				}
			}
		}
		return false

	}
	def get(p){
		def orderedPortList = [] 
		if (p.isInteger()){
			orderedPortList = scannedPorts.contains(p.intValue()) ? [p.intValue()] : null 
		}
		if(p.isRange()){
			def (portBegin,portEnd)=p.rangeValues()
			for(def port:scannedPorts){
				if ((port >= portBegin) && (port  <= portEnd) ){
					orderedPortList.add(port)
				}
			}
		}
		return orderedPortList

	}

	def scan() {

		def getUnixPorts = {  
		/*Parsing of output of netstat -anop on *Nixes*/
			def ports = [] 
			def cmd = "netstat -anop" 
			def cmdOut = cmd.execute().text 
			def lines = cmdOut.split("\n") 
			
			for (def line: lines){
				if(line.toLowerCase().contains("tcp") == false ) { continue }
				if(line.toLowerCase().contains("listen") == false) {continue}
				def tokens = line.split() as List 
				def port
				if (line.toLowerCase().contains("tcp ")){
					// if it is ipv4
					port = tokens[3].split(":")[1]
				}else if (line.toLowerCase().contains("tcp6")){
					
					port = tokens[3].split(":")[3]
				}
				

				def pid = -1 
				if (tokens[6].split('/')[0].isInteger()){
					pid = tokens[6].split('/')[0].toInteger() 
				}else{

					continue 	
				}
				
				if (port.isInteger() == false) { continue } 

				if (isValidPort(port.toInteger())){ 
					scannedPorts.add(port.toInteger())
					info[port] = [:]
					info[port]["pid"] = pid 
				}else{
					
				}

			} 
			scannedPorts.sort() 
			return scannedPorts 
		}


		def getWinPorts = {  
			def ports = [] 
			def cmd = "netstat -ano" 
			def cmdOut = cmd.execute().text 
			def lines = cmdOut.split("\r\n") 
			for (def line: lines){
				if(line.contains("TCP") != true ) { continue }
				def tokens = line.split() as List 
				def port = tokens[1].split(":")[1]
				def pid = -1 
				if (tokens[4].isInteger()){
					pid = tokens[4].toInteger() 
				}
				if (port.isInteger() == false) { continue } 
				if (isValidPort(port.toInteger())){ 
					scannedPorts.add(port.toInteger())
					info[port] = [:]
					info[port]["pid"] = pid 
					

				}

			} 
			scannedPorts.sort() 
			return scannedPorts 
		}

		if (System.properties['os.name'].toLowerCase().contains('windows')){
			return getWinPorts() 	
		}else if (System.properties['os.name'].toLowerCase().contains('linux')){
			return getUnixPorts()
		}else{
			errorLog("Undetect OS, using default: netstat -ano")
			return getWinPorts()
			
		}
		
	}
}


class Service{
	def settings
	def jmxUrls = [] 
	def context = [:]
	def scanner
	def connections=[] 
	def queryResults=[]
	def logger 
	def Service(settings){
		this.settings = settings;
		this.scanner = new PortScanner(); 
		this.logger=new Logger();
	}
	def connectAll(jmxUrls){
		connections = []
		for(def jmxUrl:jmxUrls){
			try{
				connections.add(JmxConnectorFactory.connect( new JmxServiceUrl(jmxUrl),null))
			}catch(Exception e){
				this.logger.error("Could not connect to ["+jmxUrl+"]\n Exception: "+e) 
			}
		}
		this.logger.error("connectAll" + connections) 
		return connections
	}
	def initVerboseLogging(){
		if (settings.global.keySet().contains("verbose")){
			def verbose=settings.global["verbose"].asBoolean();
			if(verbose){
				this.logger.setVerboseTrue();
			}
		}
	}
	
	def init(){
		initVerboseLogging();
		def keys = settings.config.keySet()
		for (def ns:keys){
			if (settings.isReserved(ns)){
				continue;
			}
			def ports = settings.config[ns].ports 	
			if(ports==null){
				this.logger.error("No [ports] defined for["+ns+"]");
				this.logger.verbose(settings.global);
				this.logger.verbose(settings.config);
			}else{
				ports.split(",").each { p -> scanner.add(new Port(p)) } 
			}
		}
		scanner.scan() 
		def urlBuilder = new JmxUrlBuilder(scanner)
		// check for ports setting
		for (def ns:keys){
			settings.config[ns].jmxurls = [] 
			if(settings.isReserved(ns)){
				continue
			}
			if(settings.config[ns].containsKey("jmxUrls")){
				def urls=settings.config[ns]["jmxUrls"].split(";")
				for(def u:urls){
					settings.config[ns].jmxurls.add(u) 
				}
			}
			if (settings.config[ns].containsKey("ports")){
				def nsSettings  = settings.config[ns]
				settings.config[ns].jmxurls.addAll(urlBuilder.generate(nsSettings))
			}
			settings.config[ns].jmxconnections =  connectAll(settings.config[ns].jmxurls)
			connections.addAll( settings.config[ns].jmxconnections ) 
		}
	}
	def collectData(q){ return startOn(q) }

	def startOn(queryString){
		def keys = settings.config.keySet()

		def nsResults = [] 
		for(def ns:keys){
			println "startOn:ns" + ns 
			println "startOn:execute" +  settings.config[ns].jmxconnections 
			def rs =  execute(settings.config[ns].jmxconnections , queryString )   
			queryResults.addAll(rs) 
			settings.config[ns].results = rs 
			nsResults.add(settings.config[ns]) 
		}
		return settings.config 
	} 

	def shutdown() {
	}

	def getDictionaryFromTable(padding,tbl){
		def map=[:] 
		for(def k:tbl.keySet()){
			for(def v:k){
			}
			def valueType=tbl.get(k.toArray()).getClass().getName()
			if( valueType=="javax.management.openmbean.CompositeDataSupport"){
				map[k]=getDictionaryFromComposite(padding+"+",tbl.get(k.toArray()))
			}
		}

		return map
	}
	

	def getDictionaryFromComposite(padding,property){
		def map=[:] 
		def data=property.getCompositeType()
		for(def key:data.keySet()){
			
			if ((String)property[key].getClass().getName()=="javax.management.openmbean.TabularDataSupport"){
				map[key]= this.getDictionaryFromTable(padding+"_",property[key]) 
			}

			else if ((String)property[key].getClass().getName()=="javax.management.openmbean.CompositeDataSupport"){
				map[key]=this.getDictionaryFromComposite(padding+"_",property[key]) 
			} else{
				map[key]=""+property[key]
			}
			
		}
		return map 
	} 


	def execute(connections,queryString){
		def rs=[]
		for(def c:connections){
			def bean
			def rsRow
			// if the querystring contains a *, then queryNames of connection
			// else continue as normal
			if(queryString.contains("*")){
				def oName=queryString.split("@")[0]  
				def properties=queryString.substring(queryString.indexOf("@")+ 1 ,queryString.length())
				def query=new ObjectName(oName)			
				def beans=c.MBeanServerConnection.queryNames(query,null)
				def rsRows=[]
				for(def b:beans){
					def newQueryString=""+b+"@"+properties
					rsRows.addAll(execute([c],newQueryString))
				}
				rs.addAll(rsRows)
				continue
			}

			try{
				rsRow=queryjmx(bean,c,queryString)
			}catch(javax.management.InstanceNotFoundException f){
				this.logger.error("Bad MBean Name on [" + c +"]" );
				continue
			}catch(Exception e){
				this.logger.error("Could not connect using["+c+"]")
				this.logger.error(e) 
				continue
			}

			rs.add(rsRow)
		}
		return rs 
	}


	def queryjmx(bean,c,queryString){
			def queryTokens = queryString.split("@") as List
			def mBeanName = queryTokens[0]
			queryTokens.remove(0)

			try{
				bean =  new GroovyMBean(c.MBeanServerConnection,mBeanName)		
			}catch(javax.management.InstanceNotFoundException f){
				this.logger.error("Bad MBean "+mBeanName+"  Name on [" + c +"]" );
				throw f 
			}catch(Exception e){
				this.logger.error("Could not connect to"+mBeanName+"  using["+c+"]")
				this.logger.error(e) 

				throw e
			}


			def rsRow = []
			def str="" +  c  
			def host=str.split("rmi://")[2].split("/")[0]  

			def simpleDataRow=[]
			def complexDataRow=[]
			for (def property: queryTokens){
				def beanProperty
				def compositeProperties=[]
				try{
					def p=property						
					if (property.contains(":")==true){
						println "propertysplit"+property.split(":")
						p=property.split("\\:")[0]
						compositeProperties=property.split("\\:")[1].split("\\,")
					}
					beanProperty=bean.getProperty(p)
				}catch(javax.management.AttributeNotFoundException e){
					this.logger.error("Invalid property [" + property + "] on "+ mBeanName + " at " + host )
					continue 	
				}
				def data = ["name=\"" + property+ "\""] 
 
				if (beanProperty instanceof CompositeDataSupport){
					def propertyData = [] 
					def rows=[] 
//					beanProperty.getCompositeType().keySet().each { propertyData.add(it + "=\"" + beanProperty.get(it)  +"\"") } 				

					def valueMap=this.getDictionaryFromComposite("",beanProperty)
					for(def k:valueMap.keySet()){
						if (valueMap[k] instanceof HashMap){
							def row = []
							for(def v:valueMap[k].keySet()){
								def key =  "name=\""+k + "." + v[0].replaceAll(" ","_")  +"\""
								def value=StrUtils.flatten(valueMap[k][v])
								def objectName="objectName=\""+mBeanName+"\""
								def hostVar="host=\""+host+"\""
								rows.add([key,value,objectName,hostVar])
			
							}
						}else{
							propertyData.add(""+k+"=\""+valueMap[k]+"\"")
						}
					}
					data.addAll(propertyData)	
					rsRow.add(data)
					rsRow.addAll(rows) 
					
				}else if(beanProperty instanceof TabularData){
//					data.addAll(propertyData)	
//					rsRow.add(data)
				}
				else{
					//data.addAll([ property + "=\"" + beanProperty+"\""])
					//rsRow.add(data)
			
					simpleDataRow.add(property + "=\"" + beanProperty + "\"")  
				}
				data.addAll(["host=\""+host+"\""])
				data.addAll(["objectName=\""+mBeanName+"\""])
			}
			simpleDataRow.add(" host=\""+host+"\"")
			simpleDataRow.add("objectName=\""+mBeanName+"\"")
			rsRow.add(simpleDataRow) 
			
			return rsRow

	}


}

def dataLog(data) {
	def logger = new Logger() 
	def getMetaData = { ns -> 
		label  =  (ns.label == null) ?  "" : "label"+ "=\"" + ns.label +"\""
		return label
	}
	def keys=data.keySet()
	for(def ns: keys){
		meta = getMetaData(data[ns]) 
		if (data[ns].keySet().contains("results") == false) { continue; } 
		for(def result: data[ns].results){
			tokens = []    
			result.each { row ->  logger.log(row.join(", ") + "," + meta  ) } 
		}
	
	}	
}

def settings =  Settings.newInstance()
def arguments  =  args  as List 

settings.allRequires(["ports"])
settings.addReserved("jndi")
settings.addReserved("rmi")
settings.init(_bindings) 
def service = new Service(settings) 
try{
	service.init()
}catch(Exception e){
	logger.error(e.getMessage()) 
	e.printStackTrace(perr)
}
def queryString=settings.global["query"].replaceAll("_"," ");
if (queryString==null){
	throw new Exception("Required parameter ['query'] does not exist")
}

def pollInterval=0
def pollCount=1
if (settings.global.containsKey("pollInterval") && settings.global.containsKey("pollCount") ) {
	pollInterval=settings.global["pollInterval"].toInteger()
	pollCount=settings.global["pollCount"].toInteger()
}
def counter=0

while(counter<pollCount){
	for(def query:queryString.split(";")){
		def data = service.collectData(query)  
		dataLog(data)
	}
	counter=counter+1
	Thread.sleep(pollInterval*1000)
}
service.shutdown() 
