package com.liquidlabs.groovy.mbean;

import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection

public class MBeanServers {

    def pleaseSleepMs

    //
    
    def reqGetAttribute = 0
    def reqQueryNames = 0
    
    def doneGetAttribute = 0
    def doneQueryNames = 0 
    
    def reqInvoke = 0
    def doneInvoke = 0
    
    //

    def stdErr
    
    //
    
    def MBeanServers(stdErr,pleaseSleepMs) {
        this.stdErr = stdErr
        this.pleaseSleepMs = pleaseSleepMs
    }

    def n = 0
    def mBeans = []
    def urls = []
    def connectors = []
    
    def size() {
        return mBeans.size()
    }
    def hasNext() {
        return size() > 0
    }
    def next() {
        def index = (n++) % this.size()
        return mBeans[index]
    }
    def addBean(jmxUrl) {
        try {
            def connector = JMXConnectorFactory.connect(new JMXServiceURL(jmxUrl))
            connectors.add(connector)
            try {
                def mBean = connector.getMBeanServerConnection()
                mBeans.add(mBean)
                urls.add(jmxUrl)
            } catch(E) {
                stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Could not getMBeanConnection using: " + jmxUrl + "\n"
            }
        } catch (e) {
            stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Could not create JMXServiceURL using: " + jmxUrl + "\n"
        }
    }
    def addBeans(jmxUrls) {
        jmxUrls.each { jmxUrl ->
            addBean(jmxUrl)
        }
    }
    def remove(i) {
        urls.remove(i)
        mBeans.remove(i)
        close(i)
        connectors.remove(i)
    }
    def queryNames(strName) {
        def names = "_#NONAMES"
        def beanIndex = 0
        while (names == "_#NONAMES" && beanIndex < size()) {
            def mBean = next()
            reqQueryNames++
            try {
                names = mBean.queryNames(new ObjectName(strName),null)
                doneQueryNames++
            } catch(IOException e) {
                def removeIndex = size() - 1
                stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "A communication problem occurred when talking to the MBean server: " + urls[removeIndex] + ". Ignoring it." + "\n"
                remove(removeIndex)
            } catch (Exception ex) {
                stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Exception occured when quering names: " + ex.getName() + ". Ignoring." + "\n"
                beanIndex++
            } finally {
                Thread.sleep(pleaseSleepMs)
            }
        }
        if (size() == 0) {
            stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "ERROR" + "\t" + "Ran out of MBeanConnectors" + "\n"
            throw new Exception("List of MBeanConnectors expired")
        }
        if (names == "_#NONAMES") {
            names = []
        }
        return names
    }
    def close(i) {
        try {
            connectors[i].close()
        } catch(e) {
            stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Couldn't close connection for mBean: " + urls[i] + "\n"
        }
    }
    def closeConnections() {
        for (def i = 0 ; i < size() ; i++) {
            close(i)
        }
    }


	def getMBeanInfo(id)
	{
		def isBeanInfoCollected  = false 
		def mBeanInfo = null
		def mBeanCount = 0
		
		while ( isBeanInfoCollected == false  ) 
		{
			def server = next()
			mBeanInfo = server.getMBeanInfo(id)
			isBeanInfoCollected = true
			// throw exception
		}
			
		return mBeanInfo
		
   }


	def getMbeanAttributeNames( id, attributeList )
	{
		mBeanInfo = getMBeanInfo(id)
		attributes = mBeanInfo.getAttributes()
		beanAttributes = []
		for ( attribute in attributes )
		{
			if ( attributeList.contains(attribute.getName()) )
			{
				beanAttributes.add(attribute)
			}
		}
	}

	def getAttributes(objName,attributeList)
		{
		def value = "_#NOVALUE"
		def beanIndex = 0
		while (value == "_#NOVALUE" && beanIndex < size()) {
		    def mBean = next()
		    reqGetAttribute++
		    try {
			value = mBean.getAttributes(objName,attributeList)
			doneGetAttribute++
		    } catch (javax.management.InstanceNotFoundException infe) {
			//stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Instance not found:" + objName + "\n"
			beanIndex++
            	   } catch (javax.management.AttributeNotFoundException anfe) {
                 	stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Attribute '"+attrStr+"' not found for bean:" + objName + "\n"
		    } catch (java.rmi.RemoteException e) {
				def removeIndex = size() - 1
				stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "A communication problem occurred when talking to the MBean server: " + urls[removeIndex] + ". Ignoring it." + "\n"
				e.printStackTrace(stdErr)
				urls.remove(removeIndex)
				mBeans.remove(removeIndex)
				connectors[removeIndex].close()
				connectors.remove(removeIndex)
		    } finally {
			Thread.sleep(pleaseSleepMs)
		    }
		}
		if (size() == 0) {
		    stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "ERROR" + "\t" + "Ran out of MBeanConnectors" + "\n"
		    throw new Exception("List of MBeanConnectors expired")
		}
		if (value == "_#NOVALUE") {
		    stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Got InstanceNotFoundException with all Mbean passed for attribute: " + attrStr + "\n"
		    value = "" // tried with all mbeans and got InstanceNotFoundException all the time; no value to be printed so null (happens with RemoteAddress)
		}
		return value
		
	}


    def getAttribute(objName,attrStr) {
        def value = "_#NOVALUE"
        def beanIndex = 0
        while (value == "_#NOVALUE" && beanIndex < size()) {
            def mBean = next()
            reqGetAttribute++
            try {
                value = mBean.getAttribute(objName,attrStr)
                doneGetAttribute++
            } catch (javax.management.InstanceNotFoundException infe) {
                //stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Instance not found:" + objName + "\n"
                beanIndex++
            } catch (javax.management.AttributeNotFoundException anfe) {
                 stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Attribute '"+attrStr+"' not found for bean:" + objName + "\n"
            } catch (Exception e) {
                def removeIndex = size() - 1
                stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "A communication problem occurred when talking to the MBean server: " + urls[removeIndex] + ". Ignoring it." + "\n"
                urls.remove(removeIndex)
                mBeans.remove(removeIndex)
                connectors[removeIndex].close()
                connectors.remove(removeIndex)
            } finally {
                Thread.sleep(pleaseSleepMs)
            }
        }
        if (size() == 0) {
            stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "ERROR" + "\t" + "Ran out of MBeanConnectors" + "\n"
            throw new Exception("List of MBeanConnectors expired")
        }
        if (value == "_#NOVALUE") {
            stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Got InstanceNotFoundException with all Mbean passed for attribute: " + attrStr + "\n"
            value = "" // tried with all mbeans and got InstanceNotFoundException all the time; no value to be printed so null (happens with RemoteAddress)
        }
        return value
    }
    def invoke(obj, method) {
        def mBean = next()
        reqInvoke++
        try {
            mBean.invoke(obj, method, null, null)
            doneInvoke++
        } catch (Throwable t) {
            stdErr << new Date().format("yyyy-MM-dd HH:mm:ss.SSS") + "\t" + "WARN" + "\t" + "Exception '" + t.getName() + "' when trying to reset statistics." + jmxUrls + "\n"
        }
    }
    
    def statMe() {
        def sep = "\t"
        def stats = new StringBuilder()
        stats.append(["MBeansStats:","reqQueryNames="+reqQueryNames,"reqGetAttribute="+reqGetAttribute,"reqInvoke="+reqInvoke].join(sep)).append("\n")
        return stats.toString()
    }
}
