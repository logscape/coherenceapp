#!/bin/bash

SERVICE_URLS=service:jmx:rmi://10.28.1.159:3000/jndi/rmi://10.28.1.159:9000/server
QUERY=$1
INVOKE=$2
 groovy -cp ./lib/helpers.jar jmx.groovy pollInterval=1 pollCount=1  *.group1.jmxUrls=$SERVICE_URLS *.group1.label=ll_ devMode=true query=$QUERY invokeAfter=$INVOKE
