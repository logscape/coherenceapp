import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection;
import javax.management.remote.JMXConnector;

makeSleep = makeSleep == null ? true : makeSleep
sleepMs = sleepMs == null ? 0 : sleepMs
jmxUrl = jmxUrl == null ? "service:jmx:rmi://localhost:3000/jndi/rmi://localhost:9000/server" : jmxUrl
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

//*******

//HIJACK
//jmxUrl = "service:jmx:rmi://192.168.70.226:16331/jndi/rmi://192.168.70.226:16332/server"
//jmxUrl = "215"

//*********

def scriptName = "MBeanServers.groovy"
def pathToScript = bundleId == null ? "lib/"+scriptName : "deployed-bundles/"+bundleId+"/lib/"+scriptName

def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def mBeanServersClass = loader.parseClass(new File(pathToScript))

//**********

def mBeanServers = mBeanServersClass.newInstance(stdErr,sleepMs)

try {

    mBeanServers.addBeans(jmxUrl.split(","))
    
    if (mBeanServers.size() < 1) {
        stdErr << new Date().toString() + "\t" + "ERROR" + "\t" + "Could not create connect to any of the jmx urls: " + jmxUrls + "\n"
        throw new Exception("Could not connect to any MBeanConnectors")
    }
    
    def toReturn = new StringBuilder()
    def now = new Date()
    toReturn.append(String.format('%tY-%<tm-%<td', now)).append(" ")
    toReturn.append(String.format('%tH:%<tM:%<tS.%<tL', now)).append(" : ")
    toReturn.append("Oracle Coherence GE 3.5.3/465p10 <Info> (thread=LogScape, member=0): Could connect to at least one MBeanConnector.").append("\n")
    
    stdOut << toReturn
    
    return

} catch (e) {
   
    def toReturn = new StringBuilder()
    def now = new Date()
    toReturn.append(String.format('%tY-%<tm-%<td', now)).append(" ")
    toReturn.append(String.format('%tH:%<tM:%<tS.%<tL', now)).append(" : ")
    toReturn.append("Oracle Coherence GE 3.5.3/465p10 <Warn> (thread=LogScape, member=0): Could not connect to any MBean connector.").append("\n")
    
    stdOut << toReturn
    
    return
    
} finally {
    mBeanServers.closeConnections()
}

//***

def propertyMissing(String name) {return null}