import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection

makeSleep = makeSleep == null ? true : makeSleep
sleepMs = sleepMs == null ? 0 : sleepMs
jmxUrl = jmxUrl == null ? "service:jmx:rmi://localhost:3000/jndi/rmi://localhost:9000/server" : jmxUrl
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

//******

//HIJACK
//jmxUrl = "service:jmx:rmi://192.168.70.226:16331/jndi/rmi://192.168.70.226:16332/server"

//*********

def scriptName = "MBeanServers.groovy"
def pathToScript = bundleId == null ? "lib/"+scriptName : "deployed-bundles/"+bundleId+"/lib/"+scriptName

def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def mBeanServersClass = loader.parseClass(new File(pathToScript))

//**********

def mBeanServers = mBeanServersClass.newInstance(stdErr,sleepMs)

try {
    
    mBeanServers.addBeans(jmxUrl.split(","))

    if (mBeanServers.size() < 1) {
        stdErr << new Date().toString() + "\t" + "ERROR" + "\t" + "Could not create connect to any of the jmx urls: " + jmxUrls + "\n"
        throw new Exception("Could not connect to any MBeanConnectors")
    }
    
    def keys = []
    def clientMap = [:]
    
    def clientObjNames = mBeanServers.queryNames("Coherence:type=Connection,name=*,nodeId=*,UUID=*")
    clientObjNames.each { x ->      
        try{
			def key = x.getKeyProperty('UUID')
			clientInfo = new ClientInfos(x,mBeanServers)
			clientInfo.collect()
			stdOut << clientInfo.printMe() << "\n"
		}catch(Exception e)
		{
			stdErr << e.getMessage() + "\n"
		}
                
        if (makeSleep == true) {
            Thread.sleep(10+sleepMs)
        }
    }

    
 

    return
    
} finally {
    mBeanServers.closeConnections()
}

//********

private class ClientInfos {
    def id
    def mBeanServers
    
    def proxyId = ""
    
    def ip = ""
    def uuid = ""
    
    def since = ""
    def conMs = 0
    
    def totBytesRcvd = 0
    def totBytesSent = 0
    def totMsgsRcvd = 0
    def totMsgsSent = 0
    
    def sep = ","

    public ClientInfos(x,y) {
        this.id = x
        this.mBeanServers = y
    }
    
    def collect1() {
        proxyId = id.getKeyProperty("nodeId")
        uuid = id.getKeyProperty("UUID")
        
        ip = mBeanServers.getAttribute(id, "RemoteAddress")
        
        since = mBeanServers.getAttribute(id, "Timestamp")
        conMs = mBeanServers.getAttribute(id, "ConnectionTimeMillis")
        
        totBytesRcvd = mBeanServers.getAttribute(id, "TotalBytesReceived")
        totBytesSent = mBeanServers.getAttribute(id, "TotalBytesSent")
        totMsgsRcvd = mBeanServers.getAttribute(id, "TotalMessagesReceived")
        totMsgsSent = mBeanServers.getAttribute(id, "TotalMessagesSent")
    }
    
    def printMe() {
         return new Date().toString() + sep + proxyId + sep + ip + sep + uuid + sep + since + sep + conMs + sep + totBytesRcvd + sep + totBytesSent + sep + totMsgsRcvd + sep + totMsgsSent
    }


    def collect() {

        proxyId = id.getKeyProperty("nodeId")
        uuid = id.getKeyProperty("UUID")
        
	String[]  attributeNames = ["RemoteAddress", "Timestamp", "ConnectionTimeMillis","TotalBytesReceived","TotalBytesSent", "TotalMessagesReceived","TotalMessagesSent"]

		
	def attributes = mBeanServers.getAttributes(id,attributeNames)
	def attribMap = [:]
	for ( attrib in attributes)
	{
		attribMap [ attrib.getName() ] = attrib.getValue()  
	}
		
        ip = attribMap["RemoteAddress"]
        
        since = attribMap["Timestamp"]
        conMs = attribMap["ConnectionTimeMillis"]
        totBytesRcvd = attribMap["TotalBytesReceived"]
        totBytesSent = attribMap["TotalBytesSent"]
        totMsgsRcvd = attribMap["TotalMessagesReceived"]
        totMsgsSent = attribMap["TotalMessagesSent"]	

    }

}
//*******

def propertyMissing(String name) {return null}

def getHeader() {
    def sep = ","
    return "Date" + sep + "proxyId" + sep + "ip" + sep + "uuid" + sep + "since" + sep + "conMs" + sep + "totBytesRcvd" + sep + "totBytesSent" + sep + "totMsgsRcvd" + sep + "totMsgsSent"
}
