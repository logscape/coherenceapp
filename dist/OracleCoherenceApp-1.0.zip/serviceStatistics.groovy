import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory
import javax.management.remote.JMXServiceURL
import javax.management.MBeanServerConnection

makeSleep = makeSleep == null ? true : makeSleep
sleepMs = sleepMs == null ? 0 : sleepMs
jmxUrl = jmxUrl == null ? "service:jmx:rmi://localhost:3000/jndi/rmi://localhost:9000/server" : jmxUrl
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

makeReset = makeReset == null ? true : makeReset

//****

//HIJACK
//jmxUrl = "service:jmx:rmi://192.168.70.226:16331/jndi/rmi://192.168.70.226:16332/server"
//makeReset = true

//*********

def scriptName = "MBeanServers.groovy"
//def pathToScript = bundleId == null ? "lib/"+scriptName : "deployed-bundles/"+bundleId+"/lib/"+scriptName
def pathToScript = cwd == null ? "lib/"+scriptName : cwd + "/deployed-bundles/"+bundleId+"/lib/"+scriptName

def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def mBeanServersClass = loader.parseClass(new File(pathToScript))

//**********

def mBeanServers = mBeanServersClass.newInstance(stdErr,sleepMs)

try {

    mBeanServers.addBeans(jmxUrl.split(","))

    if (mBeanServers.size() < 1) {
        stdErr << new Date().toString() + "\t" + "ERROR" + "\t" + "Could not create connect to any of the jmx urls: " + jmxUrls + "\n"
        throw new Exception("Could not connect to any MBeanConnectors")
    }
    
    def keys = []
    def serviceMap = [:]
    
    def serviceObjNames = mBeanServers.queryNames("Coherence:type=Service,name=*,nodeId=*")
    serviceObjNames.each { x ->    
	try{    
		def name = x.getKeyProperty('name')
		def nodeId = x.getKeyProperty('nodeId')
		def key = name + "-" + nodeId
		cacheServiceInfo = new CacheService(x,mBeanServers)
		cacheServiceInfo.collect()
		 
		if (makeReset == true) {
		    mBeanServers.invoke(x, "resetStatistics")
		}
	       
		if (!keys.contains(key))
		{
			stdOut <<  cacheServiceInfo.printMe() << "\n" 
			keys.add(key)
		}
	}catch(Exception e)
	{

		stdErr << e.getMessage() + "\n"

	}
    }
 
    return
    
} finally {
    mBeanServers.closeConnections()
}

//***********

private class CacheService {
    def id
    def mBeanServers
    
    def nodeId
    def name = ""
    def stats = ""
    
    public CacheService(x,y) {
     id = x
     mBeanServers = y
    }

    def collect() {
	
	String[]  attributeNames = ['name','nodeId',"Statistics"]
	
	def attributes = mBeanServers.getAttributes(id,attributeNames)
	def attribMap = [:]
	for ( attrib in attributes)
	{
		attribMap [ attrib.getName() ] = attrib.getValue()  
	}	
	
        name = id.getKeyProperty('name')
        nodeId = id.getKeyProperty('nodeId')
        stats = mBeanServers.getAttribute(id, "Statistics")       
		
    }

    def printMe() {
        def sep = ";"
        return new Date().toString() + sep + name + sep + nodeId + sep  + stats
    }
}

//******

def propertyMissing(String name) {return null}

def getHeader() {
    def sep = ";"
    return "Date" + sep + "Name" + sep + "NodeId" + sep + "Statistics"
}
